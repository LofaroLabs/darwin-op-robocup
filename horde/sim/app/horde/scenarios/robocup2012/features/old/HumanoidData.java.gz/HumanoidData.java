package sim.app.horde.scenarios.robocup2012.features;

import java.io.IOException;
import java.util.StringTokenizer;

public class HumanoidData implements Cloneable
{

	public int ballXMin;
	public int  ballXMax;
	public int  ballYMin ;
	public int  ballYMax ;
	public int  ballCamera;
	public int  blueGoalLeftXMin;
	public int  blueGoalLeftXMax;
	public int  blueGoalLeftYMin;
	public int  blueGoalLeftYMax;
	public int  blueGoalLeftCamera ;
	public int  blueGoalRightXMin;
	public int  blueGoalRightXMax;
	public int  blueGoalRightYMin ;
	public int  blueGoalRightYMax ;
	public int  blueGoalRightCamera ;
	public int  yellowGoalLeftXMin;
	public int  yellowGoalLeftXMax ;
	public int  yellowGoalLeftYMin;
	public int  yellowGoalLeftYMax ;
	public int  yellowGoalLeftCamera ;
	public int  yellowGoalRightXMin ;
	public int  yellowGoalRightXMax ;
	public int  yellowGoalRightYMin;
	public int  yellowGoalRightYMax;
	public int  yellowGoalRightCamera ;
	public int  panPos;
	public int  tiltPos; 
	public int accelerometer;
	public int gameState;
	public int gameHalf;
	public int gameScore;
	public boolean actionDone;
	
	public HumanoidData() 
	{

	}

	public Object clone()
	{
		HumanoidData hd = new HumanoidData(); 
		
		 hd.ballXMin = ballXMin;
		 hd.ballXMax = ballXMax;
		 hd.ballYMin = ballYMin ;
		 hd.ballYMax =   ballYMax ;
		 hd.ballCamera =   ballCamera;
		 hd.blueGoalLeftXMin =   blueGoalLeftXMin;
		 hd.blueGoalLeftXMax =   blueGoalLeftXMax;
		 hd.blueGoalLeftYMin =   blueGoalLeftYMin;
		 hd.blueGoalLeftYMax =   blueGoalLeftYMax;
		 hd.blueGoalLeftCamera =   blueGoalLeftCamera ;
		 hd.blueGoalRightXMin =   blueGoalRightXMin;
		 hd.blueGoalRightXMax =   blueGoalRightXMax;
		 hd.blueGoalRightYMin =   blueGoalRightYMin ;
		 hd.blueGoalRightYMax =   blueGoalRightYMax ;
		 hd.blueGoalRightCamera =   blueGoalRightCamera ;
		 hd.yellowGoalLeftXMin =   yellowGoalLeftXMin;
		 hd.yellowGoalLeftXMax =   yellowGoalLeftXMax ;
		 hd.yellowGoalLeftYMin =   yellowGoalLeftYMin;
		 hd.yellowGoalLeftYMax =   yellowGoalLeftYMax ;
		 hd.yellowGoalLeftCamera =   yellowGoalLeftCamera ;
		 hd.yellowGoalRightXMin =   yellowGoalRightXMin ;
		 hd.yellowGoalRightXMax =  yellowGoalRightXMax ;
		 hd.yellowGoalRightYMin =   yellowGoalRightYMin;
		 hd.yellowGoalRightYMax =   yellowGoalRightYMax;
		 hd.yellowGoalRightCamera =  yellowGoalRightCamera ;
		 hd.panPos =   panPos;
		 hd.tiltPos =   tiltPos; 
		 hd.accelerometer =  accelerometer;
		 hd.gameState =  gameState;
		 hd.gameHalf =  gameHalf;
		 hd.gameScore =  gameScore;
		 hd.actionDone =  actionDone;
		  
		  return hd; 
	}

	public void readData(String line) throws IOException
	{

		StringTokenizer st = new StringTokenizer(line, ":");
		
		
		 ballXMin = Integer.valueOf(st.nextToken());
		 ballXMax = Integer.valueOf(st.nextToken());
		 ballYMin = Integer.valueOf(st.nextToken());
		 ballYMax = Integer.valueOf(st.nextToken());
		 ballCamera = Integer.valueOf(st.nextToken());
		 blueGoalLeftXMin = Integer.valueOf(st.nextToken());
		 blueGoalLeftXMax = Integer.valueOf(st.nextToken());
		 blueGoalLeftYMin = Integer.valueOf(st.nextToken());
		 blueGoalLeftYMax = Integer.valueOf(st.nextToken());
		 blueGoalLeftCamera = Integer.valueOf(st.nextToken());
		 blueGoalRightXMin = Integer.valueOf(st.nextToken());
		 blueGoalRightXMax = Integer.valueOf(st.nextToken());
		 blueGoalRightYMin = Integer.valueOf(st.nextToken());
		 blueGoalRightYMax = Integer.valueOf(st.nextToken());
		 blueGoalRightCamera = Integer.valueOf(st.nextToken());
		 yellowGoalLeftXMin = Integer.valueOf(st.nextToken());
		 yellowGoalLeftXMax = Integer.valueOf(st.nextToken());
		 yellowGoalLeftYMin = Integer.valueOf(st.nextToken());
		 yellowGoalLeftYMax = Integer.valueOf(st.nextToken());
		 yellowGoalLeftCamera = Integer.valueOf(st.nextToken());
		 yellowGoalRightXMin = Integer.valueOf(st.nextToken());
		 yellowGoalRightXMax = Integer.valueOf(st.nextToken());
		 yellowGoalRightYMin = Integer.valueOf(st.nextToken());
		 yellowGoalRightYMax = Integer.valueOf(st.nextToken());
		 yellowGoalRightCamera = Integer.valueOf(st.nextToken());
		 panPos = Integer.valueOf(st.nextToken());
		 tiltPos = Integer.valueOf(st.nextToken());
		 accelerometer = Integer.valueOf(st.nextToken());
		 gameState = Integer.valueOf(st.nextToken());
		 gameHalf = Integer.valueOf(st.nextToken());
		 gameScore = Integer.valueOf(st.nextToken());
		 actionDone = (Integer.valueOf(st.nextToken())==1); 		
	}
}
