#include "debug.h"

/* This is a simple file for common debug functions. */
void print_error_message() 
{
  
}